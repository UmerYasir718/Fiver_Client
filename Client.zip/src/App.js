import "./App.css";
import MainRoutes from "./mainComponents/MainRoutes";

function App() {
  return <MainRoutes />;
}

export default App;
